<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSC584 - View Profiles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f7f6; color: #333333; padding: 20px; }
        .list-container { max-width: 1200px; background-color: #ffffff; margin: 40px auto; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        .table-thead { background-color: #3498db; color: white; }
    </style>
</head>
<body>

    <div class="list-container">
        <h2><i class="fa-solid fa-users"></i> Registered Student Profiles</h2>
        
        <div class="d-flex justify-content-end my-4">
            <a href="search.jsp" class="btn btn-dark"><i class="fa-solid fa-magnifying-glass"></i> Go to Search Page</a>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle mt-2">
                <thead class="table-thead">
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Programme</th>
                        <th>Email</th>
                        <th>Hobbies</th>
                        <th><i class="fa-solid fa-address-card"></i> Short Self Introduction</th>
                        <th class="text-center" style="width: 180px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        String dbURL = "jdbc:derby://localhost:1527/StudentProfileDB;create=true";
                        String dbUser = "Student"; 
                        String dbPass = "student"; 

                        Connection conn = null;
                        PreparedStatement ps = null;
                        ResultSet rs = null;
                        
                        try {
                            Class.forName("org.apache.derby.jdbc.ClientDriver");
                            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

                            // Plain fetch statement since searching is routed to search.jsp
                            String sql = "SELECT * FROM STUDENT.PROFILE";
                            ps = conn.prepareStatement(sql);
                            rs = ps.executeQuery();
                            boolean hasData = false;
                            
                            while (rs.next()) {
                                hasData = true;
                                String currentID = rs.getString("STUDENTID");
                    %>
                    <tr>
                        <td><strong><%= currentID %></strong></td>
                        <td><%= rs.getString("NAME") %></td>
                        <td><%= rs.getString("PROGRAMME") %></td>
                        <td><%= rs.getString("EMAIL") %></td>
                        <td><%= rs.getString("HOBBIES") %></td>
                        <td><%= rs.getString("INTRODUCTION") %></td>
                        <td class="text-center">
                            <a href="edit.jsp?studentID=<%= currentID %>" class="btn btn-warning btn-sm me-1">
                                <i class="fa-solid fa-pen-to-square"></i> Edit
                            </a>
                            <a href="delete.jsp?studentID=<%= currentID %>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this profile?');">
                                <i class="fa-solid fa-trash-can"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <%
                            }
                            if (!hasData) {
                    %>
                    <tr><td colspan="7" class="text-center text-muted py-4">No profile records found.</td></tr>
                    <%
                            }
                        } catch (Exception e) {
                    %>
                    <tr><td colspan="7" class="text-danger text-center">Database Error: <%= e.getMessage() %></td></tr>
                    <%
                        } finally {
                            if (rs != null) try { rs.close(); } catch (SQLException e) {}
                            if (ps != null) try { ps.close(); } catch (SQLException e) {}
                            if (conn != null) try { conn.close(); } catch (SQLException e) {}
                        }
                    %>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <a href="index.html" class="btn btn-outline-primary"><i class="fa-solid fa-arrow-left"></i> Back to Form</a>
        </div>
    </div>

</body>
</html>