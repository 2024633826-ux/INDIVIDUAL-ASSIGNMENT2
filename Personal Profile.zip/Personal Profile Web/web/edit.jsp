<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    String dbURL = "jdbc:derby://localhost:1527/StudentProfileDB;create=true";
    String dbUser = "Student"; 
    String dbPass = "student"; 

    String studentID = request.getParameter("studentID");
    
    // Process form updates when Save Profile is clicked (HTTP POST)
    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String name = request.getParameter("name");
        String programme = request.getParameter("programme");
        String email = request.getParameter("email");
        String hobbies = request.getParameter("hobbies");
        String introduction = request.getParameter("introduction");
        
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
            String sql = "UPDATE STUDENT.PROFILE SET name = ?, programme = ?, email = ?, hobbies = ?, introduction = ? WHERE studentID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, programme);
            ps.setString(3, email);
            ps.setString(4, hobbies);
            ps.setString(5, introduction);
            ps.setString(6, studentID);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ps != null) try { ps.close(); } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
        response.sendRedirect("viewProfile.jsp");
        return;
    }

    // Fetch existing student info to pre-fill inside the boxes (HTTP GET)
    String name = "", programme = "", email = "", hobbies = "", introduction = "";
    if (studentID != null) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
            String sql = "SELECT * FROM STUDENT.PROFILE WHERE studentID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, studentID.trim());
            rs = ps.executeQuery();
            if (rs.next()) {
                name = rs.getString("NAME");
                programme = rs.getString("PROGRAMME");
                email = rs.getString("EMAIL");
                hobbies = rs.getString("HOBBIES");
                introduction = rs.getString("INTRODUCTION");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException e) {}
            if (ps != null) try { ps.close(); } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSC584 - Edit Personal Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f7f6; color: #333333; padding: 20px; }
        .form-container { max-width: 550px; background-color: #ffffff; margin: 40px auto; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
    </style>
</head>
<body>

    <div class="form-container">
        <h2><i class="fa-solid fa-user-pen"></i> Edit Personal Profile</h2>
        
        <form action="edit.jsp?studentID=<%= studentID %>" method="POST" class="mt-4">
            <div class="mb-3">
                <label class="form-label fw-bold">Student ID:</label>
                <input type="text" class="form-control bg-light" value="<%= studentID %>" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Name:</label>
                <input type="text" name="name" class="form-control" required value="<%= name %>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Program:</label>
                <input type="text" name="programme" class="form-control" required value="<%= programme %>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Email:</label>
                <input type="email" name="email" class="form-control" required value="<%= email %>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Hobbies:</label>
                <input type="text" name="hobbies" class="form-control" required value="<%= hobbies %>">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Short Self-Introduction:</label>
                <textarea name="introduction" class="form-control" rows="4" required><%= introduction %></textarea>
            </div>
            
            <button type="submit" class="btn btn-primary w-100 text-white mt-2 py-2 fw-bold">Save Profile Updates</button>
        </form>
        
        <div class="text-center mt-3">
            <a href="viewProfile.jsp" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-list"></i> Cancel & Back</a>
        </div>
    </div>

</body>
</html>