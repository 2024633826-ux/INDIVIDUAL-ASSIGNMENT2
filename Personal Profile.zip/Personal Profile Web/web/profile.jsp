<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="model.ProfileBean" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSC584 - Profile Display</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f7f6; color: #333333; padding: 20px; }
        .profile-card { max-width: 500px; width: 100%; background-color: #ffffff; margin: 40px auto; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #2c3e50; border-bottom: 2px solid #2ecc71; padding-bottom: 10px; }
        .info-item { padding: 12px 0; border-bottom: 1px solid #eeeeee; font-size: 15px; }
        .label { font-weight: bold; color: #7f8c8d; display: inline-block; width: 130px; }
        .value { color: #2c3e50; }
        .bio-box { background-color: #f9f9f9; border-left: 4px solid #2ecc71; padding: 15px; margin-top: 20px; border-radius: 0 4px 4px 0; }
    </style>
</head>
<body>

    <div class="profile-card">
        <%
            String status = (String) request.getAttribute("status");
            ProfileBean profile = (ProfileBean) request.getAttribute("profile");
            
            if ("success".equals(status) && profile != null) {
        %>
            <h2><i class="fa-solid fa-id-card"></i> Personal Profile</h2>

            <div class="info-item"><span class="label">Name:</span><span class="value"><%= profile.getName() %></span></div>
            <div class="info-item"><span class="label">Student ID:</span><span class="value"><%= profile.getStudentID() %></span></div>
            <div class="info-item"><span class="label">Program:</span><span class="value"><%= profile.getProgramme() %></span></div>
            <div class="info-item"><span class="label">Email:</span><span class="value"><%= profile.getEmail() %></span></div>
            <div class="info-item"><span class="label">Hobbies:</span><span class="value"><%= profile.getHobbies() %></span></div>

            <div class="bio-box">
                <div class="fw-bold mb-2 text-secondary">Self-Introduction:</div>
                <div style="white-space: pre-line; color: #555555;"><%= profile.getIntroduction() %></div>
            </div>
            
            <div class="alert alert-success mt-4">🎉 Profile Successfully Saved!</div>
        <% } else { 
            String errorMsg = (String) request.getAttribute("errorMsg");
        %>
            <h2 class="text-danger"><i class="fa-solid fa-circle-exclamation"></i> System Error</h2>
            <div class="alert alert-danger mt-4">
                ❌ Failed to Save Data:<br>
                <strong><%= (errorMsg != null) ? errorMsg : "Please access this page from the main form." %></strong>
            </div>
        <% } %>

        <div class="mt-4 gap-2 d-flex justify-content-center">
            <a href="index.html" class="btn btn-primary btn-sm">Add More</a>
            <a href="viewProfile.jsp" class="btn btn-success btn-sm">View All</a>
        </div>
    </div>

</body>
</html>