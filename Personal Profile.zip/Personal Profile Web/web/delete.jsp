<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    String deleteID = request.getParameter("studentID");
    
    if (deleteID != null && !deleteID.trim().isEmpty()) {
        String dbURL = "jdbc:derby://localhost:1527/StudentProfileDB;create=true";
        String dbUser = "Student"; 
        String dbPass = "student"; 
        
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
            String sql = "DELETE FROM STUDENT.PROFILE WHERE studentID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, deleteID.trim());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ps != null) try { ps.close(); } catch (SQLException e) {}
            if (conn != null) try { conn.close(); } catch (SQLException e) {}
        }
    }
    // Selesai padam, terus kembali ke halaman utama
    response.sendRedirect("viewProfile.jsp");
%>